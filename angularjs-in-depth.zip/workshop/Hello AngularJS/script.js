'use strict';

angular.module('noteriousApp', [])
  .controller('MainCtrl', function($scope) {
      $scope.world = 'Frontend Masters';
    });

