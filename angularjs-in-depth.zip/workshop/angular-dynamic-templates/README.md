angular-dynamic-templates
=========================

Illustrates how to use dynamic templates via a directive.