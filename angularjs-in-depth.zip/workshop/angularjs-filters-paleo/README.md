angularjs-filters-paleo
=======================

Fun with AngularJS Filters - Paleo Edition
